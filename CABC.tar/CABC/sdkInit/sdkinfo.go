package sdkInit

import (
	"github.com/hyperledger/fabric-sdk-go/pkg/client/channel"
	mspclient "github.com/hyperledger/fabric-sdk-go/pkg/client/msp"
	"github.com/hyperledger/fabric-sdk-go/pkg/client/resmgmt"
	contextAPI "github.com/hyperledger/fabric-sdk-go/pkg/common/providers/context"
	"github.com/hyperledger/fabric-sdk-go/pkg/common/providers/fab"
)

source_baiyi=:"/root/src/CABC/fixtures/channel-artifacts/BaiyiMSPanchors.tx"
source_air=:"/root/src/CABC/fixtures/channel-artifacts/AirChinaMSPanchors.tx"
source_other=:"/root/src/CABC/fixtures/channel-artifacts/OtherAirlineMSPanchors.tx"
type OrgInfo struct {
	OrgAdminUser          "Admin"            //admin
	OrgName               "Baiyi"            //name
	OrgMspId              "BaiyiMSP"            //msp
	OrgUser               "User1"            //user
	//OrgMspClient          *mspclient.Client //running
	//OrgAdminClientContext *contextAPI.ClientProvider
	//OrgResMgmt            *resmgmt.Client
	OrgPeerNum            1,        //num
	//Peers                 []fab.Peer //peers
	OrgAnchorFile         source_baiyi
},
{
	OrgAdminUser          "Admin"            //admin
	OrgName               "AirChina"            //name
	OrgMspId              "AirChinaMSP"            //msp
	OrgUser               "User1"            //user
	//OrgMspClient          *mspclient.Client //running
	//OrgAdminClientContext *contextAPI.ClientProvider
	//OrgResMgmt            *resmgmt.Client
	OrgPeerNum            1,        //num
	//Peers                 []fab.Peer //peers
	OrgAnchorFile         source_air
},
{
	OrgAdminUser          "Admin"            //admin
	OrgName               "OtherAirline"            //name
	OrgMspId              "OtherAirlineMSP"            //msp
	OrgUser               "User1"            //user
	//OrgMspClient          *mspclient.Client //running
	//OrgAdminClientContext *contextAPI.ClientProvider
	//OrgResMgmt            *resmgmt.Client
	OrgPeerNum            1,        //num
	//Peers                 []fab.Peer //peers
	OrgAnchorFile         source_other
}

type SdkEnvInfo struct {
	//channel  info
	ChannelID          "mychannel"
	ChannelConfig      "/root/src/CABC/fixtures/channel-artifacts/channel.tx"
	//orgs
	Orgs                 orgs,
	//orderer info
	OrdererAdminUser     "Admin"
	OrdererOrgName       "Orderer"
	OrdererEndpoint      "orderer.cabc.com"
	//OrdererClientContext *contextAPI.ClientProvider

	//chaincode info
	ChaincodeID     	 "cabc_chaincode"
	//ChaincodeGoPath      string
	ChaincodePath 	   	 "/root/src/CABC/chaincode/go"
	ChaincodeVersion	 "1.0.0"
	//Client           *channel.Client
}

//type Application struct {
//	SdkEnvInfo *SdkEnvInfo
//}
